#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

struct _12
{
    uint _m0[1];
    uint _m1[1];
    uint _m2[1];
    uint _m3[2];
    uint _m4[4];
    uint _m5[1];
    uint _m6[2];
    uint _m7[1];
};

struct struct_uniform_0_32
{
    uint _m0[12];
};

struct struct_ubos_32
{
    uint _m0[8264];
};

struct struct_ssbos_32
{
    uint _m0[1];
};

constant uint _85 = {};
constant uint _86 = {};
constant uint _87 = {};
constant uint _88 = {};
constant uint _89 = {};
constant uint _90 = {};
constant uint _91 = {};
constant uint _92 = {};
constant uint _93 = {};
constant uint _94 = {};
constant uint _95 = {};
constant uint _96 = {};
constant uint _97 = {};
constant uint _98 = {};
constant uint _99 = {};
constant uint _100 = {};
constant uint _101 = {};
constant uint _102 = {};
constant uint _103 = {};
constant uint _104 = {};
constant uint _105 = {};
constant uint _106 = {};
constant uint _107 = {};
constant uint _108 = {};

struct spvDescriptorSetBuffer1
{
    constant void* _m0_pad [[id(0)]];
    constant struct_ubos_32* ubos_32 [[id(1)]][2];
};

struct spvDescriptorSetBuffer3
{
    constant void* _m0_pad [[id(0)]];
    const device struct_ssbos_32* ssbos_32 [[id(1)]][2];
};

struct main0_out
{
    float4 aoterm_fogFactor_selfIllumMod_healthFraction [[user(locn0)]];
    float4 uvCoords [[user(locn1)]];
    float4 uvCoords_1 [[user(locn2)]];
    float4 packed_worldNormal_VS_worldTangent_VS_x [[user(locn3)]];
    float4 packed_worldTangent_VS_yz [[user(locn4)]];
    float4 teamCol [[user(locn5)]];
    float4 gl_Position [[position]];
    float gl_ClipDistance [[clip_distance]] [1];
    float gl_ClipDistance_0 [[user(clip0)]];
};

struct main0_in
{
    float4 pos [[attribute(0)]];
    float4 normal [[attribute(1)]];
    float4 T [[attribute(2)]];
    float4 B [[attribute(3)]];
    float4 uv [[attribute(4)]];
    uint4 bonesInfo [[attribute(5)]];
    uint4 instData [[attribute(6)]];
};

vertex main0_out main0(main0_in in [[stage_in]], constant spvDescriptorSetBuffer1& spvDescriptorSet1 [[buffer(1)]], constant spvDescriptorSetBuffer3& spvDescriptorSet3 [[buffer(3)]], constant struct_uniform_0_32* uniform_0_32_0 [[buffer(17)]])
{
    constant struct_uniform_0_32* uniform_0_32[] =
    {
        uniform_0_32_0,
    };

    main0_out out = {};
    uint _173 = as_type<uint>(0.0);
    float _187 = as_type<float>(spvDescriptorSet1.ubos_32[_173]->_m0[4]) + as_type<float>(spvDescriptorSet1.ubos_32[_173]->_m0[7u]);
    int2 _197 = int2(in.instData.yx) << int2(uint2(7u, 5u) & uint2(int2(31)));
    uint _202 = as_type<uint>(0.0);
    float _212 = float(spvDescriptorSet3.ssbos_32[_202]->_m0[uint(_197.x) >> (2u & uint(31))] >> (16u & uint(31)));
    uint _213 = as_type<uint>(0.0);
    bool _84;
    uint _282;
    if (0.0 < as_type<float>(uniform_0_32[_213]->_m0[1u]))
    {
        float3 _252 = as_type<float3>(uint3(spvDescriptorSet1.ubos_32[1u]->_m0[124], spvDescriptorSet1.ubos_32[1u]->_m0[125u], spvDescriptorSet1.ubos_32[1u]->_m0[126u])) - as_type<float3>(uint3(spvDescriptorSet3.ssbos_32[_202]->_m0[uint(32 + _197.x) >> (2u & uint(31))], spvDescriptorSet3.ssbos_32[_202]->_m0[uint(36 + _197.x) >> (2u & uint(31))], spvDescriptorSet3.ssbos_32[_202]->_m0[uint(40 + _197.x) >> (2u & uint(31))]));
        float _261 = fma(_252.x, _252.x, fma(_252.y, _252.y, _252.z * _252.z));
        _84 = as_type<float>(uniform_0_32[_213]->_m0[2u]) < _261;
        _282 = ((as_type<float>(uniform_0_32[_213]->_m0[1u]) < _261) && (!_84)) ? as_type<uint>(as_type<float>(1065353216u) - ((_261 - as_type<float>(uniform_0_32[_213]->_m0[1u])) / (as_type<float>(uniform_0_32[_213]->_m0[2u]) - as_type<float>(uniform_0_32[_213]->_m0[1u])))) : 1065353216u;
    }
    else
    {
        _84 = false;
        _282 = 1065353216u;
    }
    float _291;
    float _293;
    float _320;
    float _1078;
    float _1081;
    float _1084;
    float _1111;
    float _1113;
    float _1115;
    float _1142;
    float _1144;
    float _1146;
    uint _1192;
    uint _1200;
    uint _1208;
    uint _1219;
    float _1244;
    float _1304;
    float _1315;
    float _1317;
    uint _1327;
    uint _1338;
    float _1389;
    float _1486;
    float _1488;
    float _1490;
    float _1492;
    float _1494;
    if (!_84)
    {
        _291 = in.uv.x;
        _293 = in.uv.y;
        int4 _301 = int3(20, 16, 32).xyyz + _197.xxyy;
        _320 = precise::min(precise::max(as_type<float>(spvDescriptorSet3.ssbos_32[_202]->_m0[uint(_301.x) >> (2u & uint(31))]) / as_type<float>(spvDescriptorSet3.ssbos_32[_202]->_m0[uint(_301.y) >> (2u & uint(31))]), 0.0), as_type<float>(1065353216u));
        float4 _328 = fract(float4(_212) * float4(0.00999999977648258209228515625, 0.103100001811981201171875, 0.10300000011920928955078125, 0.097300000488758087158203125));
        float3 _338 = (in.pos.xyz * float3((_328.x * 0.20000000298023223876953125) + 0.89999997615814208984375)) * as_type<float3>(uint3(_282));
        float _340 = _338.z;
        float _342 = _338.x;
        float _344 = _338.y;
        bool4 _356 = int4(uint4(uniform_0_32[_213]->_m0[4]) & uint4(2048u, 8u, 16u, 1024u)) != as_type<int4>(float4(0.0));
        if (_356.x)
        {
            float2 _373 = float2(_187) * float2(0.001333000021986663341522216796875, 0.0199999995529651641845703125);
            float _375 = floor(_373.x);
            float _381 = _375 * 5.0;
            float _383 = sin(_381);
            float _384 = sin(1.559999942779541015625 + _381);
            float _387 = (_375 + as_type<float>(1065353216u)) * 5.0;
            float _395 = precise::min(precise::max(fract(_373.x) / as_type<float>(1065353216u), 0.0), as_type<float>(1065353216u));
            float _399 = _395 * (_395 * (3.0 - (2.0 * _395)));
            float _403 = (_383 + (_399 * (sin(_387) - _383))) * 10.0;
            float _407 = (_384 + (_399 * (sin(1.559999942779541015625 + _387) - _384))) * 10.0;
            float3 _411 = _328.zwy + float3(19.1900005340576171875);
            float3 _423 = _328.yzw + float3(fma(_328.y, _411.x, fma(_328.z, _411.y, _328.w * _411.z)));
            float2 _437 = precise::min(precise::max(fract(float2(16.0) * fract((_423.xz + _423.yy) * _423.zx)), float2(0.4000000059604644775390625)), as_type<float2>(uint2(1065353216u)));
            float2 _439 = _373.yy * _437;
            float _463 = abs((fract((_439.x + 0.5) + _338.x) * 2.0) + (-1.0));
            float _464 = abs((fract(((_439.y / 3.0) + 0.5) + _437.x) * 2.0) + (-1.0));
            float _465 = abs((fract((_373.y + 0.5) + _338.z) * 2.0) + (-1.0));
            float _487 = precise::min(precise::max(precise::min(((_338.x * _338.z) * _338.y) / 3000.0, 0.20000000298023223876953125), 0.0), as_type<float>(1065353216u));
            float _492 = ((_464 * _464) * (3.0 - (2.0 * _464))) * precise::min(precise::max(_338.y / 30.0, 0.0500000007450580596923828125), 0.20000000298023223876953125);
            float _499 = (((_465 * _465) * (3.0 - (2.0 * _465))) * _487) * precise::min(precise::max(abs(_403) + abs(_407), 1.2000000476837158203125), 1.7000000476837158203125);
            _344 = _338.y + _499;
            float _502 = ((_463 * _463) * (3.0 - (2.0 * _463))) * _487;
            _342 = (_338.x + (_502 + (_492 * _403))) + _499;
            _340 = (_338.z + (_502 + (_492 * _407))) + _499;
        }
        else
        {
        }
        float3 _541 = select(in.T.xyz, float2(1.0, 0.0).xyy, bool3(fast::min(fma(in.T.x, in.T.x, fma(in.T.y, in.T.y, in.T.z * in.T.z)), fma(in.B.x, in.B.x, fma(in.B.y, in.B.y, in.B.z * in.B.z))) < 0.100000001490116119384765625));
        int _552 = ((int(in.bonesInfo.x & 255u) << int(1u & uint(31))) + int(in.instData.x)) << int(5u & uint(31));
        int4 _559 = int4(_552) + int4(64, 80, 96, 112);
        uint _563 = uint(_559.x) >> (2u & uint(31));
        uint _572 = uint(68 + _552) >> (2u & uint(31));
        uint _579 = uint(72 + _552) >> (2u & uint(31));
        uint _586 = uint(76 + _552) >> (2u & uint(31));
        uint4 _589 = uint4(spvDescriptorSet3.ssbos_32[1u]->_m0[_563], spvDescriptorSet3.ssbos_32[1u]->_m0[_572], spvDescriptorSet3.ssbos_32[1u]->_m0[_579], spvDescriptorSet3.ssbos_32[1u]->_m0[_586]);
        uint4 _617 = uint4(spvDescriptorSet3.ssbos_32[1u]->_m0[uint(_559.y) >> (2u & uint(31))], spvDescriptorSet3.ssbos_32[1u]->_m0[uint(84 + _552) >> (2u & uint(31))], spvDescriptorSet3.ssbos_32[1u]->_m0[uint(88 + _552) >> (2u & uint(31))], spvDescriptorSet3.ssbos_32[1u]->_m0[uint(92 + _552) >> (2u & uint(31))]);
        uint _621 = uint(_559.z) >> (2u & uint(31));
        uint _628 = uint(100 + _552) >> (2u & uint(31));
        uint _635 = uint(104 + _552) >> (2u & uint(31));
        uint _642 = uint(108 + _552) >> (2u & uint(31));
        uint4 _645 = uint4(spvDescriptorSet3.ssbos_32[1u]->_m0[_621], spvDescriptorSet3.ssbos_32[1u]->_m0[_628], spvDescriptorSet3.ssbos_32[1u]->_m0[_635], spvDescriptorSet3.ssbos_32[1u]->_m0[_642]);
        float _676 = precise::min(precise::max(as_type<float>(spvDescriptorSet1.ubos_32[_173]->_m0[7u]), 0.0), as_type<float>(1065353216u));
        float4 _701 = as_type<float4>(_589) + (float4(_676) * (as_type<float4>(select(_645, as_type<uint4>(-as_type<float4>(_645)), bool4(fma(as_type<float>(spvDescriptorSet3.ssbos_32[1u]->_m0[_563]), as_type<float>(spvDescriptorSet3.ssbos_32[1u]->_m0[_621]), fma(as_type<float>(spvDescriptorSet3.ssbos_32[1u]->_m0[_572]), as_type<float>(spvDescriptorSet3.ssbos_32[1u]->_m0[_628]), fma(as_type<float>(spvDescriptorSet3.ssbos_32[1u]->_m0[_579]), as_type<float>(spvDescriptorSet3.ssbos_32[1u]->_m0[_635]), as_type<float>(spvDescriptorSet3.ssbos_32[1u]->_m0[_586]) * as_type<float>(spvDescriptorSet3.ssbos_32[1u]->_m0[_642])))) < 0.0))) - as_type<float4>(_589)));
        float4 _716 = _701 * float4(rsqrt(fma(_701.x, _701.x, fma(_701.y, _701.y, fma(_701.z, _701.z, _701.w * _701.w)))));
        float4 _723 = as_type<float4>(_617) + (float4(_676) * (as_type<float4>(uint4(spvDescriptorSet3.ssbos_32[1u]->_m0[uint(_559.w) >> (2u & uint(31))], spvDescriptorSet3.ssbos_32[1u]->_m0[uint(116 + _552) >> (2u & uint(31))], spvDescriptorSet3.ssbos_32[1u]->_m0[uint(120 + _552) >> (2u & uint(31))], spvDescriptorSet3.ssbos_32[1u]->_m0[uint(124 + _552) >> (2u & uint(31))])) - as_type<float4>(_617)));
        float _726 = _342 * _723.w;
        float _729 = _344 * _723.w;
        float _732 = _340 * _723.w;
        float3 _735 = _716.zyx * float3(_732);
        float3 _744 = float3(2.0 * fma(_716.x, _726, fma(_716.y, _729, _735.x))) * _716.xyz;
        float2 _747 = _716.wz * _716.wz;
        float _756 = _747.x - fma(_716.x, _716.x, fma(_716.y, _716.y, _747.y));
        float _767 = 2.0 * _716.w;
        float2 _770 = _716.zy * float2(_726);
        float2 _773 = _716.xz * float2(_729);
        float4 _798 = _716.zyzx * in.normal.zzxy;
        float3 _821 = ((float3(2.0 * fma(_716.x, in.normal.x, fma(_716.y, in.normal.y, _798.x))) * _716.xyz) + (float3(_756) * in.normal.xyz)) + (float3(_767) * (_798.yzw - (_716.zxy * in.normal.yzx)));
        float4 _824 = _716.zyzx * _541.zzxy;
        float3 _846 = ((float3(2.0 * fma(_716.x, _541.x, fma(_716.y, _541.y, _824.x))) * _716.xyz) + (float3(_756) * _541)) + (float3(_767) * (_824.yzw - (_716.zxy * _541.yzx)));
        uint _850 = uint(_197.y) >> (2u & uint(31));
        uint _857 = uint(_197.y + 4) >> (2u & uint(31));
        uint _864 = uint(_197.y + 8) >> (2u & uint(31));
        uint _871 = uint(_197.y + 12) >> (2u & uint(31));
        uint4 _874 = uint4(spvDescriptorSet3.ssbos_32[1u]->_m0[_850], spvDescriptorSet3.ssbos_32[1u]->_m0[_857], spvDescriptorSet3.ssbos_32[1u]->_m0[_864], spvDescriptorSet3.ssbos_32[1u]->_m0[_871]);
        uint4 _904 = uint4(spvDescriptorSet3.ssbos_32[1u]->_m0[uint(_301.z) >> (2u & uint(31))], spvDescriptorSet3.ssbos_32[1u]->_m0[uint(20 + _197.y) >> (2u & uint(31))], spvDescriptorSet3.ssbos_32[1u]->_m0[uint(24 + _197.y) >> (2u & uint(31))], spvDescriptorSet3.ssbos_32[1u]->_m0[uint(28 + _197.y) >> (2u & uint(31))]);
        uint _908 = uint(_301.w) >> (2u & uint(31));
        uint _915 = uint(36 + _197.y) >> (2u & uint(31));
        uint _922 = uint(40 + _197.y) >> (2u & uint(31));
        uint _930 = uint(44 + _197.y) >> (2u & uint(31));
        uint4 _933 = uint4(spvDescriptorSet3.ssbos_32[1u]->_m0[_908], spvDescriptorSet3.ssbos_32[1u]->_m0[_915], spvDescriptorSet3.ssbos_32[1u]->_m0[_922], spvDescriptorSet3.ssbos_32[1u]->_m0[_930]);
        int2 _937 = int2(48, 4) + _197.yx;
        float4 _991 = as_type<float4>(_874) + (float4(_676) * (as_type<float4>(select(_933, as_type<uint4>(-as_type<float4>(_933)), bool4(fma(as_type<float>(spvDescriptorSet3.ssbos_32[1u]->_m0[_850]), as_type<float>(spvDescriptorSet3.ssbos_32[1u]->_m0[_908]), fma(as_type<float>(spvDescriptorSet3.ssbos_32[1u]->_m0[_857]), as_type<float>(spvDescriptorSet3.ssbos_32[1u]->_m0[_915]), fma(as_type<float>(spvDescriptorSet3.ssbos_32[1u]->_m0[_864]), as_type<float>(spvDescriptorSet3.ssbos_32[1u]->_m0[_922]), as_type<float>(spvDescriptorSet3.ssbos_32[1u]->_m0[_871]) * as_type<float>(spvDescriptorSet3.ssbos_32[1u]->_m0[_930])))) < 0.0))) - as_type<float4>(_874)));
        float4 _1006 = _991 * float4(rsqrt(fma(_991.x, _991.x, fma(_991.y, _991.y, fma(_991.z, _991.z, _991.w * _991.w)))));
        float4 _1013 = as_type<float4>(_904) + (float4(_676) * (as_type<float4>(uint4(spvDescriptorSet3.ssbos_32[1u]->_m0[uint(_937.x) >> (2u & uint(31))], spvDescriptorSet3.ssbos_32[1u]->_m0[uint(52 + _197.y) >> (2u & uint(31))], spvDescriptorSet3.ssbos_32[1u]->_m0[uint(56 + _197.y) >> (2u & uint(31))], spvDescriptorSet3.ssbos_32[1u]->_m0[uint(60 + _197.y) >> (2u & uint(31))])) - as_type<float4>(_904)));
        float _1015 = (((_744.x + (_756 * _726)) + (_767 * (_735.y - _773.y))) + _723.x) * _1013.w;
        float _1017 = (((_744.y + (_756 * _729)) + (_767 * (_770.x - _735.z))) + _723.y) * _1013.w;
        float _1019 = (((_744.z + (_756 * _732)) + (_767 * (_773.x - _770.y))) + _723.z) * _1013.w;
        float3 _1022 = _1006.zyx * float3(_1019);
        float3 _1031 = float3(2.0 * fma(_1006.x, _1015, fma(_1006.y, _1017, _1022.x))) * _1006.xyz;
        float2 _1034 = _1006.wz * _1006.wz;
        float _1043 = _1034.x - fma(_1006.x, _1006.x, fma(_1006.y, _1006.y, _1034.y));
        float _1054 = 2.0 * _1006.w;
        float2 _1057 = _1006.zy * float2(_1015);
        float2 _1060 = _1006.xz * float2(_1017);
        _1078 = ((_1031.x + (_1043 * _1015)) + (_1054 * (_1022.y - _1060.y))) + _1013.x;
        _1081 = ((_1031.y + (_1043 * _1017)) + (_1054 * (_1057.x - _1022.z))) + _1013.y;
        _1084 = ((_1031.z + (_1043 * _1019)) + (_1054 * (_1060.x - _1057.y))) + _1013.z;
        float4 _1087 = _1006.zyzx * _846.zzxy;
        float3 _1109 = ((float3(2.0 * fma(_1006.x, _846.x, fma(_1006.y, _846.y, _1087.x))) * _1006.xyz) + (float3(_1043) * _846)) + (float3(_1054) * (_1087.yzw - (_1006.zxy * _846.yzx)));
        _1111 = _1109.z;
        _1113 = _1109.x;
        _1115 = _1109.y;
        float4 _1118 = _1006.zyzx * _821.zzxy;
        float3 _1140 = ((float3(2.0 * fma(_1006.x, _821.x, fma(_1006.y, _821.y, _1118.x))) * _1006.xyz) + (float3(_1043) * _821)) + (float3(_1054) * (_1118.yzw - (_1006.zxy * _821.yzx)));
        _1142 = _1140.z;
        _1144 = _1140.x;
        _1146 = _1140.y;
        uint2 _1151 = in.instData.zz & uint2(65535u, 2047u);
        uint _1153 = _1151.y;
        if (_1151.x >= 2048u)
        {
            _1153 = spvDescriptorSet3.ssbos_32[_202]->_m0[uint(_937.y) >> (2u & uint(31))] & 255u;
        }
        else
        {
        }
        if (int(_1151.x) != int(255u))
        {
            if ((_1153 < 2048u) && (int(_1153) != int(255u)))
            {
                int _1185 = int(_1153) << int(uint(4) & uint(31));
                _1192 = spvDescriptorSet1.ubos_32[_173]->_m0[uint(288 + _1185) >> (2u & uint(31))];
                _1200 = spvDescriptorSet1.ubos_32[_173]->_m0[uint(292 + _1185) >> (2u & uint(31))];
                _1208 = spvDescriptorSet1.ubos_32[_173]->_m0[uint(296 + _1185) >> (2u & uint(31))];
            }
            else
            {
                _1208 = 1065353216u;
                _1200 = 1065353216u;
                _1192 = 1065353216u;
            }
        }
        else
        {
            _1208 = as_type<uint>(0.0);
            _1200 = as_type<uint>(0.0);
            _1192 = as_type<uint>(0.0);
        }
        _1219 = spvDescriptorSet3.ssbos_32[_202]->_m0[uint(88 + _197.x) >> (2u & uint(31))];
        uint _1224 = uint(92 + _197.x) >> (2u & uint(31));
        float _1235 = precise::min(precise::max((as_type<float>(spvDescriptorSet1.ubos_32[_173]->_m0[5u]) - abs(as_type<float>(spvDescriptorSet3.ssbos_32[_202]->_m0[_1224]))) * 3.3333332538604736328125, 0.0), as_type<float>(1065353216u));
        _1244 = (0.0 < as_type<float>(spvDescriptorSet3.ssbos_32[_202]->_m0[_1224])) ? _1235 : ((as_type<float>(spvDescriptorSet3.ssbos_32[_202]->_m0[_1224]) < 0.0) ? (as_type<float>(1065353216u) - _1235) : 0.0);
        float3 _1258 = as_type<float3>(uint3(spvDescriptorSet1.ubos_32[1u]->_m0[160u], spvDescriptorSet1.ubos_32[1u]->_m0[161u], spvDescriptorSet1.ubos_32[1u]->_m0[162u])) * float3(_1078);
        float3 _1272 = as_type<float3>(uint3(spvDescriptorSet1.ubos_32[1u]->_m0[164u], spvDescriptorSet1.ubos_32[1u]->_m0[165u], spvDescriptorSet1.ubos_32[1u]->_m0[166u])) * float3(_1081);
        float3 _1289 = as_type<float3>(uint3(spvDescriptorSet1.ubos_32[1u]->_m0[168u], spvDescriptorSet1.ubos_32[1u]->_m0[169u], spvDescriptorSet1.ubos_32[1u]->_m0[170u])) * float3(_1084);
        _1304 = ((_1258.z + _1272.z) + _1289.z) + as_type<float>(spvDescriptorSet1.ubos_32[1u]->_m0[174u]);
        float2 _1313 = (((_1258.xy + float2(0.5)) + _1272.xy) + _1289.xy) + as_type<float2>(uint2(spvDescriptorSet1.ubos_32[1u]->_m0[172u], spvDescriptorSet1.ubos_32[1u]->_m0[173u]));
        _1315 = _1313.x;
        _1317 = _1313.y;
        _1327 = _356.y ? as_type<uint>(precise::min(precise::max(fract(in.uv.x * 16384.0), 0.100000001490116119384765625), as_type<float>(1065353216u))) : 1065353216u;
        _1338 = _356.z ? as_type<uint>(precise::max(-0.20000000298023223876953125, sin(((_187 * 2.0) / 30.0) + (_212 * 0.100000001490116119384765625))) + 0.20000000298023223876953125) : 1065353216u;
        if (_356.w)
        {
            float3 _1365 = (((as_type<float3>(uint3(spvDescriptorSet1.ubos_32[1u]->_m0[48u], spvDescriptorSet1.ubos_32[1u]->_m0[49u], spvDescriptorSet1.ubos_32[1u]->_m0[50u])) * float3(_1078)) + (as_type<float3>(uint3(spvDescriptorSet1.ubos_32[1u]->_m0[52], spvDescriptorSet1.ubos_32[1u]->_m0[53u], spvDescriptorSet1.ubos_32[1u]->_m0[54u])) * float3(_1081))) + (as_type<float3>(uint3(spvDescriptorSet1.ubos_32[1u]->_m0[56], spvDescriptorSet1.ubos_32[1u]->_m0[57u], spvDescriptorSet1.ubos_32[1u]->_m0[58u])) * float3(_1084))) + as_type<float3>(uint3(spvDescriptorSet1.ubos_32[1u]->_m0[60], spvDescriptorSet1.ubos_32[1u]->_m0[61u], spvDescriptorSet1.ubos_32[1u]->_m0[62u]));
            _1389 = precise::min(precise::max((as_type<float>(spvDescriptorSet1.ubos_32[_173]->_m0[25u]) - sqrt(fma(_1365.x, _1365.x, fma(_1365.y, _1365.y, _1365.z * _1365.z)))) * as_type<float>(spvDescriptorSet1.ubos_32[_173]->_m0[27u]), 0.0), as_type<float>(1065353216u));
        }
        else
        {
        }
        if (int(uniform_0_32[_213]->_m0[as_type<uint>(0.0)] & uint(4)) != as_type<int>(0.0))
        {
            float4 _1466 = (((as_type<float4>(uint4(spvDescriptorSet1.ubos_32[1u]->_m0[240u], spvDescriptorSet1.ubos_32[1u]->_m0[241u], spvDescriptorSet1.ubos_32[1u]->_m0[242u], spvDescriptorSet1.ubos_32[1u]->_m0[243u])) * float4(_1078)) + (as_type<float4>(uint4(spvDescriptorSet1.ubos_32[1u]->_m0[244u], spvDescriptorSet1.ubos_32[1u]->_m0[245u], spvDescriptorSet1.ubos_32[1u]->_m0[246u], spvDescriptorSet1.ubos_32[1u]->_m0[247u])) * float4(_1081))) + (as_type<float4>(uint4(spvDescriptorSet1.ubos_32[1u]->_m0[248u], spvDescriptorSet1.ubos_32[1u]->_m0[249u], spvDescriptorSet1.ubos_32[1u]->_m0[250u], spvDescriptorSet1.ubos_32[1u]->_m0[251u])) * float4(_1084))) + as_type<float4>(uint4(spvDescriptorSet1.ubos_32[1u]->_m0[252u], spvDescriptorSet1.ubos_32[1u]->_m0[253u], spvDescriptorSet1.ubos_32[1u]->_m0[254u], spvDescriptorSet1.ubos_32[1u]->_m0[255u]));
            _1486 = fma(_1078, as_type<float>(uniform_0_32[_213]->_m0[5u]), fma(_1081, as_type<float>(uniform_0_32[_213]->_m0[6u]), fma(_1084, as_type<float>(uniform_0_32[_213]->_m0[7u]), as_type<float>(uniform_0_32[_213]->_m0[8]))));
            _1488 = _1466.x;
            _1490 = _1466.y;
            _1492 = _1466.z;
            _1494 = _1466.w;
        }
        else
        {
            float4 _1559 = (((as_type<float4>(uint4(spvDescriptorSet1.ubos_32[1u]->_m0[80u], spvDescriptorSet1.ubos_32[1u]->_m0[81u], spvDescriptorSet1.ubos_32[1u]->_m0[82u], spvDescriptorSet1.ubos_32[1u]->_m0[83u])) * float4(_1078)) + (as_type<float4>(uint4(spvDescriptorSet1.ubos_32[1u]->_m0[84], spvDescriptorSet1.ubos_32[1u]->_m0[85u], spvDescriptorSet1.ubos_32[1u]->_m0[86u], spvDescriptorSet1.ubos_32[1u]->_m0[87u])) * float4(_1081))) + (as_type<float4>(uint4(spvDescriptorSet1.ubos_32[1u]->_m0[88], spvDescriptorSet1.ubos_32[1u]->_m0[89u], spvDescriptorSet1.ubos_32[1u]->_m0[90u], spvDescriptorSet1.ubos_32[1u]->_m0[91u])) * float4(_1084))) + as_type<float4>(uint4(spvDescriptorSet1.ubos_32[1u]->_m0[92], spvDescriptorSet1.ubos_32[1u]->_m0[93u], spvDescriptorSet1.ubos_32[1u]->_m0[94u], spvDescriptorSet1.ubos_32[1u]->_m0[95u]));
            _1488 = _1559.x;
            _1490 = _1559.y;
            _1492 = _1559.z;
            _1494 = _1559.w;
            _1486 = 0.0;
        }
    }
    else
    {
        _1486 = 0.0;
        _1494 = as_type<float>(1065353216u);
        _1492 = as_type<float>(3221225472u);
        _1490 = 0.0;
        _1488 = 0.0;
    }
    out.gl_Position = float4(_1488, _1490, _1492, _1494);
    out.gl_ClipDistance[as_type<uint>(0.0)] = _1486;
    out.uvCoords = float4(_1315, _1317, _1304, _291);
    out.packed_worldNormal_VS_worldTangent_VS_x = float4(_1081, _1084, _1144, _1146);
    out.packed_worldTangent_VS_yz = float4(_1142, _1113, _1115, _1111);
    out.teamCol = as_type<float4>(uint4(_1192, _1200, _1208, _1219));
    out.aoterm_fogFactor_selfIllumMod_healthFraction = as_type<float4>(uint4(_1327, as_type<uint>(_1389), _1338, as_type<uint>(as_type<float>(1065353216u) - _320)));
    out.uvCoords_1 = float4(_293, _212 + 0.5, _1244, _1078);
    out.gl_ClipDistance_0 = out.gl_ClipDistance[0];
    out.gl_Position.y = -(out.gl_Position.y);    // Invert Y-axis for Metal
    return out;
}

