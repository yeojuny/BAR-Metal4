#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

struct _12
{
    uint _m0[1];
    uint _m1[1];
    uint _m2[1];
    uint _m3[2];
    uint _m4[4];
    uint _m5[1];
    uint _m6[2];
    uint _m7[1];
};

struct struct_ubos_32
{
    uint _m0[1092];
};

constant uint _53 = {};
constant uint _54 = {};
constant uint _55 = {};
constant uint _56 = {};
constant uint _57 = {};
constant uint _58 = {};
constant uint _59 = {};
constant uint _60 = {};

struct spvDescriptorSetBuffer1
{
    constant void* _m0_pad [[id(0)]];
    constant struct_ubos_32* ubos_32 [[id(1)]][2];
};

struct spvDescriptorSetBuffer2
{
    texture2d<float> heightmapTex [[id(0)]];
    sampler heightmapTexSmplr [[id(1)]];
};

struct main0_out
{
    float4 g_position [[user(locn0)]];
    float4 g_uv [[user(locn1)]];
    float4 packed_tbnmatrix_0_tbnmatrix_1_x [[user(locn2)]];
    float packed_tbnmatrix_1_yz_tbnmatrix_2_xy [[user(locn3)]];
    float4 gl_Position [[position]];
};

struct main0_in
{
    float4 xyworld_xyfract [[attribute(0)]];
    float4 lengthwidthrotation [[attribute(1)]];
    float4 uvoffsets [[attribute(2)]];
    float4 alphastart_alphadecay_heatstart_heatdecay [[attribute(3)]];
    float4 worldPos [[attribute(4)]];
    float4 parameters [[attribute(5)]];
};

vertex main0_out main0(main0_in in [[stage_in]], constant spvDescriptorSetBuffer1& spvDescriptorSet1 [[buffer(1)]], constant spvDescriptorSetBuffer2& spvDescriptorSet2 [[buffer(2)]])
{
    main0_out out = {};
    uint _67 = as_type<uint>(0.0);
    float _84 = (as_type<float>(spvDescriptorSet1.ubos_32[_67]->_m0[4u]) + as_type<float>(spvDescriptorSet1.ubos_32[_67]->_m0[7u])) - in.worldPos.w;
    float _98 = precise::min(precise::max((precise::min(1.0, _84 / in.parameters.w) * in.alphastart_alphadecay_heatstart_heatdecay.x) - (_84 * in.alphastart_alphadecay_heatstart_heatdecay.y), 0.0), in.lengthwidthrotation.w);
    bool _52;
    if (_98 >= 0.00999999977648258209228515625)
    {
        float3 _121 = in.worldPos.xyz - as_type<float3>(uint3(spvDescriptorSet1.ubos_32[1u]->_m0[124u], spvDescriptorSet1.ubos_32[1u]->_m0[125u], spvDescriptorSet1.ubos_32[1u]->_m0[126u]));
        float3 _174 = (((as_type<float3>(uint3(spvDescriptorSet1.ubos_32[1u]->_m0[80u], spvDescriptorSet1.ubos_32[1u]->_m0[81u], spvDescriptorSet1.ubos_32[1u]->_m0[83u])) * in.worldPos.xxx) + (as_type<float3>(uint3(spvDescriptorSet1.ubos_32[1u]->_m0[84u], spvDescriptorSet1.ubos_32[1u]->_m0[85u], spvDescriptorSet1.ubos_32[1u]->_m0[87u])) * in.worldPos.yyy)) + (as_type<float3>(uint3(spvDescriptorSet1.ubos_32[1u]->_m0[88u], spvDescriptorSet1.ubos_32[1u]->_m0[89u], spvDescriptorSet1.ubos_32[1u]->_m0[91u])) * in.worldPos.zzz)) + as_type<float3>(uint3(spvDescriptorSet1.ubos_32[1u]->_m0[92u], spvDescriptorSet1.ubos_32[1u]->_m0[93u], spvDescriptorSet1.ubos_32[1u]->_m0[95u]));
        float2 _191 = abs(_174.xy);
        _52 = (_174.z * (1.0 + ((in.lengthwidthrotation.x + in.lengthwidthrotation.y) * rsqrt(fma(_121.x, _121.x, fma(_121.y, _121.y, _121.z * _121.z)))))) < fast::max(_191.y, _191.x);
    }
    else
    {
        _52 = true;
    }
    float _197 = cos(in.lengthwidthrotation.z);
    float _214;
    float _232;
    float _234;
    float _240;
    float _246;
    float _293;
    float _357;
    float _370;
    float _372;
    float _374;
    float _376;
    float _378;
    if (!_52)
    {
        float2 _209 = in.xyworld_xyfract.xy * (in.lengthwidthrotation.xy * float2(0.5));
        float _211 = sin(in.lengthwidthrotation.z);
        _214 = -_211;
        float2 _216 = float2(_197) * _209;
        float2 _218 = float2(_211) * _209;
        float2 _230 = in.uvoffsets.xz + ((in.uvoffsets.yw - in.uvoffsets.xz) * ((in.xyworld_xyfract.xy * float2(0.5)) + float2(0.5)));
        _232 = _230.x;
        _234 = _230.y;
        _240 = (_216.x + in.worldPos.x) + _218.y;
        _246 = (in.worldPos.z - _218.x) + _216.y;
        uint2 _257 = uint2(spvDescriptorSet1.ubos_32[_67]->_m0[12u], spvDescriptorSet1.ubos_32[_67]->_m0[13u]);
        float2 _260 = float2(1.0) / as_type<float2>(_257);
        float2 _279 = as_type<float2>(_257) + float2(-8.0);
        _293 = spvDescriptorSet2.heightmapTex.sample(spvDescriptorSet2.heightmapTexSmplr, float2(precise::min(precise::max(_240 + (((_240 * (-8.0)) * _260.x) + 4.0), 8.0), _279.x) * _260.x, precise::min(precise::max(_246 + (((_246 * (-8.0)) * _260.y) + 4.0), 8.0), _279.y) * _260.y), level(0.0)).x + 0.5;
        float4 _352 = (((as_type<float4>(uint4(spvDescriptorSet1.ubos_32[1u]->_m0[80u], spvDescriptorSet1.ubos_32[1u]->_m0[81u], spvDescriptorSet1.ubos_32[1u]->_m0[82u], spvDescriptorSet1.ubos_32[1u]->_m0[83u])) * float4(_240)) + (as_type<float4>(uint4(spvDescriptorSet1.ubos_32[1u]->_m0[84u], spvDescriptorSet1.ubos_32[1u]->_m0[85u], spvDescriptorSet1.ubos_32[1u]->_m0[86u], spvDescriptorSet1.ubos_32[1u]->_m0[87u])) * float4(_293))) + (as_type<float4>(uint4(spvDescriptorSet1.ubos_32[1u]->_m0[88u], spvDescriptorSet1.ubos_32[1u]->_m0[89u], spvDescriptorSet1.ubos_32[1u]->_m0[90u], spvDescriptorSet1.ubos_32[1u]->_m0[91u])) * float4(_246))) + as_type<float4>(uint4(spvDescriptorSet1.ubos_32[1u]->_m0[92u], spvDescriptorSet1.ubos_32[1u]->_m0[93u], spvDescriptorSet1.ubos_32[1u]->_m0[94u], spvDescriptorSet1.ubos_32[1u]->_m0[95u]));
        _357 = _352.z - (512.0 / _352.w);
        _370 = in.alphastart_alphadecay_heatstart_heatdecay.z * exp2((((_84 >= in.parameters.y) ? (-0.047608934342861175537109375) : 0.0) * (_84 - in.parameters.y)) * in.alphastart_alphadecay_heatstart_heatdecay.w);
        _372 = _352.x;
        _374 = _352.y;
        _376 = _352.w;
        _378 = _214;
    }
    else
    {
        _357 = as_type<float>(3221225472u);
        _376 = 1.0;
        _374 = as_type<float>(3221225472u);
        _372 = as_type<float>(3221225472u);
    }
    out.gl_Position = float4(_372, _374, _357, _376);
    out.g_position = float4(in.parameters.xz, _370, _240);
    out.g_uv = float4(_293, _246, _98, _232);
    out.packed_tbnmatrix_0_tbnmatrix_1_x = float4(_234, _197, _214, _378);
    out.packed_tbnmatrix_1_yz_tbnmatrix_2_xy = -_197;
    out.gl_Position.y = -(out.gl_Position.y);    // Invert Y-axis for Metal
    return out;
}

