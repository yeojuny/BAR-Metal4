
#ifndef RECOIL_NATIVE_SAMPLE_SHADING_PRELUDE
#define RECOIL_NATIVE_SAMPLE_SHADING_PRELUDE 1
#define RECOIL_NATIVE_SAMPLE_SHADING_ANNOTATED 1
#include <metal_stdlib>
using namespace metal;
#ifndef RECOIL_NATIVE_SAMPLE_SHADING
#define RECOIL_NATIVE_SAMPLE_SHADING 0
#endif
#if RECOIL_NATIVE_SAMPLE_SHADING
#define RECOIL_SAMPLE_PERSPECTIVE sample_perspective
#define RECOIL_SAMPLE_NOPERSPECTIVE sample_no_perspective
#define RECOIL_SAMPLE_ID_ARGUMENT , uint recoilOriginalSampleID [[sample_id]]
#define RECOIL_SAMPLE_POSITION_ARGUMENT
// Metal's built-in position remains center_no_perspective even for a sample
// function. Its depth and reciprocal-W are screen-linear planes. Evaluate those
// planes at the actual sample; xy uses the hardware sample position explicitly.
inline float4 RecoilOriginalSamplePosition(float4 center, float2 samplePosition) {
	const float2 offset=samplePosition-float2(0.5f);
	float4 result=center+dfdx(center)*offset.x+dfdy(center)*offset.y;
	result.xy=floor(center.xy)+samplePosition;
	return result;
}
#define RECOIL_SAMPLE_FIX_POSITION(value, samplePosition) value=RecoilOriginalSamplePosition(value,samplePosition)
#else
#define RECOIL_SAMPLE_PERSPECTIVE center_perspective
#define RECOIL_SAMPLE_NOPERSPECTIVE center_no_perspective
#define RECOIL_SAMPLE_ID_ARGUMENT
#define RECOIL_SAMPLE_POSITION_ARGUMENT
#define RECOIL_SAMPLE_FIX_POSITION(value, samplePosition)
#endif
#endif
#pragma clang diagnostic ignored "-Wmissing-prototypes"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

struct Transform
{
    float4 quat;
    float4 trSc;
};

struct UniformMatrixBuffer
{
    float4x4 screenView;
    float4x4 screenProj;
    float4x4 screenViewProj;
    float4x4 cameraView;
    float4x4 cameraProj;
    float4x4 cameraViewProj;
    float4x4 cameraBillboardView;
    float4x4 cameraViewInv;
    float4x4 cameraProjInv;
    float4x4 cameraViewProjInv;
    float4x4 shadowView;
    float4x4 shadowProj;
    float4x4 shadowViewProj;
    float4x4 reflectionView;
    float4x4 reflectionProj;
    float4x4 reflectionViewProj;
    float4x4 orthoProj01;
    float4x4 mmDrawView;
    float4x4 mmDrawProj;
    float4x4 mmDrawViewProj;
    float4x4 mmDrawIMMView;
    float4x4 mmDrawIMMProj;
    float4x4 mmDrawIMMViewProj;
    float4x4 mmDrawDimView;
    float4x4 mmDrawDimProj;
    float4x4 mmDrawDimViewProj;
};

struct UniformParamsBuffer
{
    packed_float3 rndVec3;
    uint renderCaps;
    float4 timeInfo;
    float4 viewGeometry;
    float4 mapSize;
    float4 mapHeight;
    float4 fogColor;
    float4 fogParams;
    float4 sunDir;
    float4 sunAmbientModel;
    float4 sunAmbientMap;
    float4 sunDiffuseModel;
    float4 sunDiffuseMap;
    float4 sunSpecularModel;
    float4 sunSpecularMap;
    float4 shadowDensity;
    float4 windInfo;
    float2 mouseScreenPos;
    uint mouseStatus;
    uint mouseUnused;
    float4 mouseWorldPos;
    float4 teamColor[255];
};

struct SUniformsBuffer
{
    uint composite;
    uint unused2;
    uint unused3;
    uint unused4;
    float maxHealth;
    float health;
    float unused5;
    float unused6;
    float4 drawPos;
    float4 speed;
    float4 userDefined[4];
};

struct UniformsBuffer
{
    SUniformsBuffer uni[1];
};

struct Transform_1
{
    float4 quat;
    float4 trSc;
};

struct TransformBuffer
{
    Transform_1 transforms[1];
};

struct Data
{
    float4 pieceVertexPosOrig;
    float4 worldVertexPos;
    float3 worldTangent_VS;
    float3 worldNormal_VS;
    float4 uvCoords;
    float4 teamCol;
    float4 shadowVertexPos;
    float4 aoterm_fogFactor_selfIllumMod_healthFraction;
};

struct NativeCUSDrawUniforms
{
    float3 NativeCUSWater0;
    float3 NativeCUSWater1;
    packed_float3 NativeCUSWater2;
    int drawPass;
    float featureFadeDistSq;
    float featureDrawDistSq;
    float baseVertexDisplacement;
    int bitOptions;
    float4 clipPlane0;
    uint NativeCUSClipFlags;
};

struct NativeCUSVertex_out
{
    float4 m_553_pieceVertexPosOrig [[user(locn0)]];
    float4 m_553_worldVertexPos [[user(locn1)]];
    float3 m_553_worldTangent_VS [[user(locn2)]];
    float3 m_553_worldNormal_VS [[user(locn3)]];
    float4 m_553_uvCoords [[user(locn4)]];
    float4 m_553_teamCol [[user(locn5)]];
    float4 m_553_shadowVertexPos [[user(locn6)]];
    float4 m_553_aoterm_fogFactor_selfIllumMod_healthFraction [[user(locn7)]];
    float4 gl_Position [[position]];
    float gl_ClipDistance [[clip_distance]] [1];
};

struct NativeCUSVertex_in
{
    float3 pos [[attribute(0)]];
    float3 normal [[attribute(1)]];
    float3 T [[attribute(2)]];
    float3 B [[attribute(3)]];
    float4 uv [[attribute(4)]];
    uint3 bonesInfo [[attribute(5)]];
    uint4 instData [[attribute(6)]];
};

static inline __attribute__((always_inline))
float2 GetWind(thread const float& period)
{
    float2 wind = sin(float2(0.0, 1.559999942779541015625) + float2(period * 5.0));
    return wind * 10.0;
}

static inline __attribute__((always_inline))
float3 hash31(thread const float& p)
{
    float3 p3 = fract(float3(p) * float3(0.103100001811981201171875, 0.10300000011920928955078125, 0.097300000488758087158203125));
    p3 += float3(dot(p3, p3.yzx + float3(19.1900005340576171875)));
    return fract((p3.xxy + p3.yzz) * p3.zyx);
}

static inline __attribute__((always_inline))
void DoWindVertexMove(thread float4& mVP, thread float& simFrame, const device UniformsBuffer& _297, thread uint4& instData)
{
    float simFrameFloor = floor(simFrame * 0.001333000021986663341522216796875);
    float simFrameFract = fract(simFrame * 0.001333000021986663341522216796875);
    float param = simFrameFloor;
    float2 curWind = GetWind(param);
    float param_1 = simFrameFloor + 1.0;
    float2 nextWind = GetWind(param_1);
    float tweenFactor = smoothstep(0.0, 1.0, simFrameFract);
    float2 wind = mix(curWind, nextWind, float2(tweenFactor));
    float param_2 = float(_297.uni[instData.y].composite >> uint(16));
    float3 modelXYZ = hash31(param_2) * 16.0;
    modelXYZ = fract(modelXYZ);
    modelXYZ = fast::clamp(modelXYZ, float3(0.4000000059604644775390625), float3(1.0));
    float abswind = abs(wind.x) + abs(wind.y);
    float simTime = 0.0199999995529651641845703125 * simFrame;
    float4 cosVec;
    cosVec.w = 0.0;
    cosVec.x = (simTime * modelXYZ.x) + mVP.x;
    cosVec.y = ((simTime * modelXYZ.z) / 3.0) + modelXYZ.x;
    cosVec.z = (simTime * 1.0) + mVP.z;
    float4 tri = abs((fract(cosVec + float4(0.5)) * 2.0) - float4(1.0));
    cosVec = (tri * tri) * (float4(3.0) - (tri * 2.0));
    float limit = fast::clamp(((mVP.x * mVP.z) * mVP.y) / 3000.0, 0.0, 0.20000000298023223876953125);
    float diff = cosVec.x * limit;
    float diff2 = cosVec.y * fast::clamp(mVP.y / 30.0, 0.0500000007450580596923828125, 0.20000000298023223876953125);
    float4 _414 = mVP;
    float3 _417 = _414.xyz + float3((cosVec.z * limit) * fast::clamp(abswind, 1.2000000476837158203125, 1.7000000476837158203125));
    mVP.x = _417.x;
    mVP.y = _417.y;
    mVP.z = _417.z;
    float4 _430 = mVP;
    float2 _432 = _430.xz + (float2(diff) + (wind * diff2));
    mVP.x = _432.x;
    mVP.z = _432.y;
}

static inline __attribute__((always_inline))
uint GetUnpackedValue(thread const uint& packedValue, thread const uint& byteNum)
{
    return (packedValue >> (8u * byteNum)) & 255u;
}

static inline __attribute__((always_inline))
float4 Lerp(thread const float4& qa, thread float4& qb, thread const float& t)
{
    if (dot(qa, qb) < 0.0)
    {
        qb = -qb;
    }
    return fast::normalize(mix(qa, qb, float4(t)));
}

static inline __attribute__((always_inline))
Transform Lerp(thread const Transform& t0, thread const Transform& t1, thread float& a)
{
    a = fast::clamp(a, 0.0, 1.0);
    float4 param = t0.quat;
    float4 param_1 = t1.quat;
    float param_2 = a;
    float4 _206 = Lerp(param, param_1, param_2);
    return Transform{ _206, mix(t0.trSc, t1.trSc, float4(a)) };
}

static inline __attribute__((always_inline))
float3 RotateByQuaternion(thread const float4& q, thread const float3& v)
{
    return ((q.xyz * (2.0 * dot(q.xyz, v))) + (v * ((q.w * q.w) - dot(q.xyz, q.xyz)))) + (cross(q.xyz, v) * (2.0 * q.w));
}

static inline __attribute__((always_inline))
float4 ApplyTransform(thread const Transform& tra, thread const float4& v)
{
    float4 param = tra.quat;
    float3 param_1 = v.xyz * tra.trSc.w;
    return float4(RotateByQuaternion(param, param_1) + (tra.trSc.xyz * v.w), v.w);
}

static inline __attribute__((always_inline))
void GetModelSpaceVertex(thread const float3& displacedPos, thread float4& msPosition, thread float3& msNormal, thread const float3& safeTangent, thread float3& msTangent, thread const float3& safeBitangent, thread float3& msBitangent, constant UniformParamsBuffer& _102, thread uint4& instData, thread uint3& bonesInfo, const device TransformBuffer& _473, thread float3& normal)
{
    bool staticModel = false;
    float4 piecePos = float4(displacedPos, 1.0);
    uint param = bonesInfo.y;
    uint param_1 = 0u;
    float4 weights = float4(float(GetUnpackedValue(param, param_1)) / 255.0, 0.0, 0.0, 0.0);
    uint param_2 = bonesInfo.x;
    uint param_3 = 0u;
    uint bID0 = GetUnpackedValue(param_2, param_3);
    Transform tx;
    if (staticModel)
    {
        uint _477 = instData.x + bID0;
        tx.quat = _473.transforms[_477].quat;
        tx.trSc = _473.transforms[_477].trSc;
    }
    else
    {
        uint _492 = (instData.x + (2u * (1u + bID0))) + 0u;
        uint _499 = (instData.x + (2u * (1u + bID0))) + 1u;
        Transform param_4;
        param_4.quat = _473.transforms[_492].quat;
        param_4.trSc = _473.transforms[_492].trSc;
        Transform param_5;
        param_5.quat = _473.transforms[_499].quat;
        param_5.trSc = _473.transforms[_499].trSc;
        float param_6 = _102.timeInfo.w;
        Transform _517 = Lerp(param_4, param_5, param_6);
        tx = _517;
    }
    weights.x *= float(tx.trSc.w > 0.0);
    Transform param_7 = tx;
    float4 param_8 = piecePos;
    msPosition = ApplyTransform(param_7, param_8);
    float4 param_9 = tx.quat;
    float3 param_10 = normal;
    msNormal = RotateByQuaternion(param_9, param_10);
    float4 param_11 = tx.quat;
    float3 param_12 = safeTangent;
    msTangent = RotateByQuaternion(param_11, param_12);
    float4 param_13 = tx.quat;
    float3 param_14 = safeBitangent;
    msBitangent = RotateByQuaternion(param_13, param_14);
}

static inline __attribute__((always_inline))
void NativeCUSOriginalMain(constant UniformMatrixBuffer& _73, thread float& simFrame, constant UniformParamsBuffer& _102, const device UniformsBuffer& _297, thread uint4& instData, thread uint3& bonesInfo, const device TransformBuffer& _473, thread float3& normal, thread Data& _553, thread float3& pos, thread float4& uv, constant NativeCUSDrawUniforms& _608, thread float3& T, thread float3& B, thread float4& gl_Position, thread float (&gl_ClipDistance)[1])
{
    _553.uvCoords.z = float(_297.uni[instData.y].composite >> uint(16));
    float featureFadeFactor = 1.0;
    float4 piecePos = float4(pos, 1.0);
    _553.uvCoords.x = uv.xy.x;
    _553.uvCoords.y = uv.xy.y;
    _553.aoterm_fogFactor_selfIllumMod_healthFraction.w = fast::clamp(_297.uni[instData.y].health / _297.uni[instData.y].maxHealth, 0.0, 1.0);
    float4 _592 = piecePos;
    float3 _594 = _592.xyz * featureFadeFactor;
    piecePos.x = _594.x;
    piecePos.y = _594.y;
    piecePos.z = _594.z;
    _553.pieceVertexPosOrig = piecePos;
    float3 modelVertexNormal = normal;
    if ((uint(_608.bitOptions) & 2048u) != 0u)
    {
        float4 param = piecePos;
        DoWindVertexMove(param, simFrame, _297, instData);
        piecePos = param;
    }
    float4 modelPos = float4(pos, 1.0);
    float3 safeT = T;
    float3 safeB = B;
    bool _638 = dot(safeT, safeT) < 0.100000001490116119384765625;
    bool _646;
    if (!_638)
    {
        _646 = dot(safeB, safeB) < 0.100000001490116119384765625;
    }
    else
    {
        _646 = _638;
    }
    if (_646)
    {
        safeT = float3(1.0, 0.0, 0.0);
        safeB = float3(0.0, 0.0, 1.0);
    }
    float3 param_1 = piecePos.xyz;
    float3 param_4 = safeT;
    float3 param_6 = safeB;
    float4 param_2;
    float3 param_3;
    float3 param_5;
    float3 param_7;
    GetModelSpaceVertex(param_1, param_2, param_3, param_4, param_5, param_6, param_7, _102, instData, bonesInfo, _473, normal);
    modelPos = param_2;
    modelVertexNormal = param_3;
    float3 modelSpaceTangent = param_5;
    float3 modelSpaceBitangent = param_7;
    uint _672 = instData.x + 0u;
    uint _675 = instData.x + 1u;
    Transform param_8;
    param_8.quat = _473.transforms[_672].quat;
    param_8.trSc = _473.transforms[_672].trSc;
    Transform param_9;
    param_9.quat = _473.transforms[_675].quat;
    param_9.trSc = _473.transforms[_675].trSc;
    float param_10 = _102.timeInfo.w;
    Transform _693 = Lerp(param_8, param_9, param_10);
    Transform modelToWorldTX = _693;
    Transform param_11 = modelToWorldTX;
    float4 param_12 = modelPos;
    float4 worldPos = ApplyTransform(param_11, param_12);
    float4 param_13 = modelToWorldTX.quat;
    float3 param_14 = modelSpaceTangent;
    _553.worldTangent_VS = RotateByQuaternion(param_13, param_14);
    float4 param_15 = modelToWorldTX.quat;
    float3 param_16 = modelVertexNormal;
    _553.worldNormal_VS = RotateByQuaternion(param_15, param_16);
    _553.pieceVertexPosOrig.w = modelPos.y / fast::max(1.0, ((device float*)&_297.uni[instData.y].userDefined[2])[3u]);
    uint teamIndex = instData.z & 255u;
    _553.teamCol = ((teamIndex == 255u) ? float4(0.0) : _102.teamColor[teamIndex]);
    _553.teamCol.w = ((device float*)&_297.uni[instData.y].userDefined[1])[2u];
    float4 lightVertexPos = _73.shadowView * worldPos;
    float3 lightVertexNormal = normal;
    float NdotL = fast::clamp(dot(lightVertexNormal, float3(0.0, 0.0, 1.0)), 0.0, 1.0);
    float bias0 = 4.9999998736893758177757263183594e-05 * tan(acos(NdotL));
    bias0 = fast::clamp(bias0, 0.0, 0.00025000001187436282634735107421875);
    float4 _761 = lightVertexPos;
    float2 _763 = _761.xy + float2(0.5);
    lightVertexPos.x = _763.x;
    lightVertexPos.y = _763.y;
    lightVertexPos.z += bias0;
    gl_Position = _73.shadowProj * lightVertexPos;
}

vertex NativeCUSVertex_out NativeCUSVertex(NativeCUSVertex_in in [[stage_in]], constant UniformMatrixBuffer& _73 [[buffer(2)]], constant UniformParamsBuffer& _102 [[buffer(3)]], const device TransformBuffer& _473 [[buffer(4)]], const device UniformsBuffer& _297 [[buffer(5)]], constant NativeCUSDrawUniforms& _608 [[buffer(6)]])
{
    NativeCUSVertex_out out = {};
    Data _553 = {};
    float3 cameraPos = _73.cameraViewInv[3].xyz;
    float3 cameraDir = float3(_73.cameraView[0].z, _73.cameraView[1].z, _73.cameraView[2].z) * (-1.0);
    float simFrame = _102.timeInfo.x + _102.timeInfo.w;
    out.gl_ClipDistance[0] = 1.0;
    NativeCUSOriginalMain(_73, simFrame, _102, _297, in.instData, in.bonesInfo, _473, in.normal, _553, in.pos, in.uv, _608, in.T, in.B, out.gl_Position, out.gl_ClipDistance);
    if ((_608.NativeCUSClipFlags & 1u) != 0u)
    {
        out.gl_Position.z = (out.gl_Position.z + out.gl_Position.w) * 0.5;
    }
    if ((_608.NativeCUSClipFlags & 2u) != 0u)
    {
        out.gl_Position.y = -out.gl_Position.y;
    }
    if ((_608.NativeCUSClipFlags & 4u) == 0u)
    {
        out.gl_ClipDistance[0] = 1.0;
    }
    out.m_553_pieceVertexPosOrig = _553.pieceVertexPosOrig;
    out.m_553_worldVertexPos = _553.worldVertexPos;
    out.m_553_worldTangent_VS = _553.worldTangent_VS;
    out.m_553_worldNormal_VS = _553.worldNormal_VS;
    out.m_553_uvCoords = _553.uvCoords;
    out.m_553_teamCol = _553.teamCol;
    out.m_553_shadowVertexPos = _553.shadowVertexPos;
    out.m_553_aoterm_fogFactor_selfIllumMod_healthFraction = _553.aoterm_fogFactor_selfIllumMod_healthFraction;
    return out;
}

